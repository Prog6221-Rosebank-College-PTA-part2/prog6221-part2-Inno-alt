﻿using System;
using System.Threading;

namespace CyberGuard
{
    public class UIManager
    {
        public void ShowLogo()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            string logo = @"
    ╔═══════════════════════════════════════════════════════════════════╗
    ║                                                                   ║
    ║       ██████╗██╗   ██╗██████╗ ███████╗██████╗  ██████╗ ██████╗    ║
    ║      ██╔════╝╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗██╔════╝ ██╔══██╗   ║
    ║      ██║      ╚████╔╝ ██████╔╝█████╗  ██████╔╝██║  ███╗██████╔╝    ║
    ║      ██║       ╚██╔╝  ██╔══██╗██╔══╝  ██╔══██╗██║   ██║██╔══██╗    ║
    ║      ╚██████╗   ██║   ██████╔╝███████╗██║  ██║╚██████╔╝██║  ██║    ║
    ║       ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝    ║
    ║                                                                   ║
    ║                         🔒  C Y B E R G U A R D  🔒               ║
    ║                    Your Personal Security Assistant               ║
    ║                                                                   ║
    ╚═══════════════════════════════════════════════════════════════════╝";

            Console.WriteLine(logo);
            Console.ResetColor();
            Thread.Sleep(1000);
        }

        public void ShowWelcome()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n" + new string('=', 65));
            Console.WriteLine("  🛡️  WELCOME TO CYBERGUARD - YOUR SECURITY BOT  🛡️");
            Console.WriteLine(new string('=', 65));
            Console.ResetColor();
        }

        public void TypeMessage(string message, int speed = 30)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            foreach (char c in message)
            {
                Console.Write(c);
                Thread.Sleep(speed);
            }
            Console.WriteLine();
            Console.ResetColor();
        }

        public void ShowPrompt()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            
            Console.ResetColor();
        }

        public void AskName()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("\n👤 What's your name? ");
            Console.ResetColor();
        }

        public void ShowError(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"❌ {message}");
            Console.ResetColor();
        }

        public void ShowGoodbye(string name)
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine($"\n👋 Hamba kahle {name}! Stay safe online!");
            Console.WriteLine("🔐 Remember: Strong passwords = Strong protection!");
            Console.ResetColor();
        }

        public void AddSeparator()
        {
            Console.WriteLine(new string('─', 55));
        }

        public void ShowMenu()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n📋 CYBERGUARD MENU:");
            Console.ResetColor();
            Console.WriteLine("  • 'how are you' - Check on me");
            Console.WriteLine("  • 'what is your purpose' - Why I exist");
            Console.WriteLine("  • 'password tips' - Learn about strong passwords");
            Console.WriteLine("  • 'phishing' - Avoid email scams");
            Console.WriteLine("  • 'safe browsing' - Browse safely online");
            Console.WriteLine("  • '2fa' - Two-factor authentication guide");
            Console.WriteLine("  • 'menu' - Show this menu");
            Console.WriteLine("  • 'exit' - Leave CyberGuard");
            AddSeparator();
        }
    }
}
