﻿using System;
using System.Collections.Generic;

namespace CyberGuard
{
    public class ResponseHandler
    {
        // Automatic properties
        public string BotName { get; set; } = "CyberGuard";
        public string Version { get; set; } = "2.0";
        public bool Online { get; set; } = true;

        private Dictionary<string, string> replies;

        public ResponseHandler()
        {
            LoadReplies();
        }

        private void LoadReplies()
        {
            replies = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                { "how are you", "I'm locked and loaded! Ready to help you stay secure. How can I assist you today?" },
                { "purpose", "CyberGuard exists to protect you from online threats. I teach password safety, phishing detection, and secure browsing habits!" },
                { "password tips", "🔐 STRONG PASSWORD RULES:\n• 12+ characters long\n• Mix of A-Z, a-z, 0-9, and symbols\n• No dictionary words\n• Never reuse passwords\n• Use a password manager like Bitwarden!" },
                { "phishing", "🎣 PHISHING ALERT!\n• Check sender email addresses carefully\n• Hover before clicking links\n• Look for spelling mistakes\n• Never share personal info via email\n• When in doubt, delete it!" },
                { "safe browsing", "🌐 SAFE BROWSING 101:\n• Always check for 'https://'\n• Avoid public Wi-Fi for banking\n• Keep your browser updated\n• Use a VPN on public networks\n• Clear cookies and cache regularly!" },
                { "2fa", "📱 TWO-FACTOR AUTHENTICATION:\n• Adds an extra security layer\n• Use Google Authenticator or Authy\n• Never share verification codes\n• Save backup codes safely\n• Enable 2FA on all important accounts!" },
                { "menu", "Type 'menu' to see all my features!" }
            };
        }

        public string GetReply(string input, string userName)
        {
            // Empty input check
            if (string.IsNullOrWhiteSpace(input))
            {
                return "Hi Say something, I'm listening!";
            }

            // Menu command
            if (input.Equals("menu", StringComparison.OrdinalIgnoreCase))
            {
                UIManager ui = new UIManager();
                ui.ShowMenu();
                return "What would you like to learn about, " + userName + "?";
            }

            // Greetings
            if (input.Contains("hello", StringComparison.OrdinalIgnoreCase) ||
                input.Contains("hi", StringComparison.OrdinalIgnoreCase) ||
                input.Contains("hey", StringComparison.OrdinalIgnoreCase))
            {
                return $"hello {userName}! Great to connect with you. Ready to level up your security?";
            }

            // Thank you
            if (input.Contains("thank", StringComparison.OrdinalIgnoreCase) ||
                input.Contains("thanks", StringComparison.OrdinalIgnoreCase))
            {
                return $"No problem {userName}! That's what CyberGuard is here for. Stay sharp!";
            }

            // Match keywords
            foreach (var item in replies)
            {
                if (input.ToLower().Contains(item.Key.ToLower()))
                {
                    return item.Value;
                }
            }

            // Default response
            return $"Hey {userName}, I didn't understand '{input}'. Try asking about passwords, phishing, or type 'menu' for options!";
        }
    }
}
