﻿using System;
using System.Threading;

namespace CyberGuard
{
    public class Chatbot
    {
        private UIManager ui;
        private ResponseHandler responses;
        private AudioManager audio;
        private string userName;

        public Chatbot()
        {
            ui = new UIManager();
            responses = new ResponseHandler();
            audio = new AudioManager();
        }

        public void Start()
        {
            // Play voice greeting
            audio.PlayWelcome();

            // Show ASCII art
            ui.ShowLogo();

            // Show welcome message
            ui.ShowWelcome();

            // Get user name
            userName = GetUserName();

            // Personalized greeting
            ui.TypeMessage($"\nhii {userName}! Welcome to CyberGuard. I'm here to help you stay safe online. Type 'menu' to see what I can do, or 'exit' to leave.", 35);
            Console.WriteLine();

            // Main loop
            string input;
            do
            {
                ui.ShowPrompt();
                input = Console.ReadLine()?.Trim() ?? "";

                if (input.Equals("exit", StringComparison.OrdinalIgnoreCase))
                {
                    ui.ShowGoodbye(userName);
                    break;
                }

                string reply = responses.GetReply(input, userName);
                ui.TypeMessage(reply, 40);
                ui.AddSeparator();

            } while (true);
        }

        private string GetUserName()
        {
            string name = "";
            while (string.IsNullOrWhiteSpace(name))
            {
                ui.AskName();
                name = Console.ReadLine()?.Trim() ?? "";

                if (string.IsNullOrWhiteSpace(name))
                {
                    ui.ShowError("Hello I didn't catch that. Please tell me your name:");
                }
                else if (name.Length < 2)
                {
                    ui.ShowError("That's too short! Please enter your full name:");
                    name = "";
                }
            }
            return name;
        }
    }
}