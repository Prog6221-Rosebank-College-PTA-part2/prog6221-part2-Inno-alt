﻿using System;

namespace CyberGuard
{
    class Program
    {
        static void Main(string[] args)
        {
            Chatbot chatbot = new Chatbot();
            chatbot.Start();
        }
    }
}