﻿using System;
using System.Diagnostics;

namespace CyberGuard
{
    public class AudioManager
    {
        public void PlayWelcome()
        {
            Speak("Welcome to CyberGuard. I am here to help you stay safe online.");
        }

        public void SpeakResponse(string message)
        {
            Speak(message);
        }

        private void Speak(string message)
        {
            try
            {
                // For Mac
                Process.Start("say", $"\"{message}\"");

                // For Linux (uncomment if on Linux)
                // Process.Start("espeak", $"\"{message}\"");
            }
            catch
            {
                Console.WriteLine(message);
            }
        }
    }
}