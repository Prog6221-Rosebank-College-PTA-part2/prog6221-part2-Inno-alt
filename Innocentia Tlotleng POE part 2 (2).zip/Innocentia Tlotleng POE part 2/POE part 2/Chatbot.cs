﻿
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CybersecurityChatbotWPF
{
    public class Chatbot
    {
        private string _userName;
        private List<string> _userInterests;
        private List<string> _conversationHistory;
        private string _currentTopic;
        private Random _random;

        private Dictionary<string, List<string>> _keywordResponses;
        private Dictionary<string, List<string>> _randomTips;

        private List<string> _worriedKeywords;
        private List<string> _frustratedKeywords;
        private List<string> _curiousKeywords;
        private List<string> _positiveKeywords;

        public Chatbot()
        {
            _userName = string.Empty;
            _userInterests = new List<string>();
            _conversationHistory = new List<string>();
            _currentTopic = string.Empty;
            _random = new Random();

            InitializeKeywordResponses();
            InitializeRandomTips();
            InitializeSentimentKeywords();
        }

        private void InitializeKeywordResponses()
        {
            _keywordResponses = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase)
            {
                { "password", new List<string> {
                    "Use strong passwords with at least 12 characters including uppercase, lowercase, numbers, and symbols.",
                    "Never reuse the same password across multiple accounts.",
                    "Consider using a password manager to generate and store complex passwords.",
                    "Enable Two-Factor Authentication whenever possible for an extra layer of security."
                }},
                { "phishing", new List<string> {
                    "Always verify the sender's email address before clicking any links.",
                    "Look for spelling errors and urgent language in emails - these are common phishing tactics.",
                    "Never share personal information via email or text message.",
                    "Hover over links to see the actual URL before clicking."
                }},
                { "safe browsing", new List<string> {
                    "Look for HTTPS and the padlock icon in the address bar before entering sensitive information.",
                    "Avoid using public Wi-Fi for banking or shopping without a VPN.",
                    "Keep your browser and extensions updated to the latest versions.",
                    "Clear your browser cache and cookies regularly."
                }},
                { "2fa", new List<string> {
                    "Two-Factor Authentication adds a second verification step to your login process.",
                    "Use authenticator apps like Google Authenticator instead of SMS when possible.",
                    "Always save your backup codes in a secure location.",
                    "2FA can prevent 99.9 percent of automated account takeovers."
                }},
                { "malware", new List<string> {
                    "Keep your antivirus software updated at all times.",
                    "Only download software from official websites.",
                    "Be cautious of email attachments from unknown senders.",
                    "Enable automatic updates for your operating system."
                }},
                { "privacy", new List<string> {
                    "Review your social media privacy settings regularly.",
                    "Be mindful of what personal information you share online.",
                    "Use unique answers for security questions.",
                    "Consider using a VPN to encrypt your internet traffic."
                }}
            };
        }

        private void InitializeRandomTips()
        {
            _randomTips = new Dictionary<string, List<string>>
            {
                { "general", new List<string> {
                    "Always log out of accounts when using shared computers.",
                    "Create a unique email alias for important accounts.",
                    "Regularly check your bank statements for unauthorized transactions.",
                    "Use a screen lock on all your devices, even at home.",
                    "Back up your important files to an external drive or cloud storage."
                }},
                { "password", new List<string> {
                    "Avoid using dictionary words or common phrases as passwords.",
                    "Longer passwords are generally stronger than complex short ones.",
                    "Change your passwords immediately if a service reports a data breach.",
                    "Never write down passwords on sticky notes near your computer."
                }},
                { "phishing", new List<string> {
                    "When in doubt about an email, contact the sender through official channels.",
                    "Scammers often create urgency to make you act without thinking.",
                    "Check for mismatched email addresses and domain names.",
                    "Legitimate companies will never ask for your password via email."
                }}
            };
        }

        private void InitializeSentimentKeywords()
        {
            _worriedKeywords = new List<string>
            {
                "worried", "scared", "fear", "anxious", "nervous",
                "concerned", "afraid", "unsafe", "vulnerable",
                "panic", "threatened", "risky", "dangerous"
            };

            _frustratedKeywords = new List<string>
            {
                "frustrated", "annoyed", "angry", "upset", "tired",
                "confused", "difficult", "hard", "complicated",
                "useless", "waste", "pointless", "stupid"
            };

            _curiousKeywords = new List<string>
            {
                "curious", "interested", "want to know", "tell me",
                "learn", "understand", "explain", "how does",
                "why is", "what is", "tell me about"
            };

            _positiveKeywords = new List<string>
            {
                "great", "good", "excellent", "helpful", "thanks",
                "thank you", "awesome", "perfect", "clear", "easy"
            };
        }

        public async Task<string> ProcessInput(string userInput)
        {
            if (string.IsNullOrWhiteSpace(userInput))
            {
                return "Please enter a message. I am here to help with cybersecurity.";
            }

            LogConversation($"User: {userInput}");

            string sentiment = DetectSentiment(userInput);

            UpdateMemory(userInput);

            string response = GetResponse(userInput);

            if (sentiment == "Worried" || sentiment == "Frustrated")
            {
                string empathyResponse = GetEmpathyResponse(sentiment);
                response = empathyResponse + " " + response;
            }

            if (sentiment == "Curious")
            {
                string curiousResponse = GetEmpathyResponse(sentiment);
                response = curiousResponse + " " + response;
            }

            LogConversation($"Bot: {response}");

            return await Task.FromResult(response);
        }

        private string GetResponse(string userInput)
        {
            if (string.IsNullOrEmpty(_userName) && !userInput.Contains("name", StringComparison.OrdinalIgnoreCase))
            {
                return "I don't know your name yet. Could you please tell me?";
            }

            if (userInput.Contains("my name is", StringComparison.OrdinalIgnoreCase) ||
                userInput.Contains("call me", StringComparison.OrdinalIgnoreCase))
            {
                string newName = ExtractName(userInput);
                _userName = newName;
                return $"Nice to meet you {_userName}! How can I help you with cybersecurity today?";
            }

            if (userInput.Contains("tell me more", StringComparison.OrdinalIgnoreCase) ||
                userInput.Contains("explain more", StringComparison.OrdinalIgnoreCase) ||
                userInput.Contains("continue", StringComparison.OrdinalIgnoreCase))
            {
                return HandleFollowUp();
            }

            if (userInput.Contains("another tip", StringComparison.OrdinalIgnoreCase) ||
                userInput.Contains("give me a tip", StringComparison.OrdinalIgnoreCase))
            {
                return GetRandomTip(userInput);
            }

            if (userInput.Contains("thank", StringComparison.OrdinalIgnoreCase))
            {
                if (!string.IsNullOrEmpty(_userName))
                {
                    return $"You are welcome {_userName}! Stay safe online!";
                }
                return "You are welcome! Stay safe online!";
            }

            string response = MatchKeyword(userInput);

            if (response != null)
            {
                _currentTopic = ExtractTopic(userInput);
                return response;
            }

            _currentTopic = string.Empty;
            return GetDefaultResponse(userInput);
        }

        private string MatchKeyword(string userInput)
        {
            foreach (var keyword in _keywordResponses.Keys)
            {
                if (userInput.Contains(keyword, StringComparison.OrdinalIgnoreCase))
                {
                    List<string> responses = _keywordResponses[keyword];
                    return responses[_random.Next(responses.Count)];
                }
            }
            return null;
        }

        private string HandleFollowUp()
        {
            if (string.IsNullOrEmpty(_currentTopic))
            {
                return "What topic would you like me to explain more about? I know about passwords, phishing, safe browsing, and 2FA.";
            }

            if (_keywordResponses.ContainsKey(_currentTopic))
            {
                List<string> responses = _keywordResponses[_currentTopic];
                return $"Let me share more: {responses[_random.Next(responses.Count)]}";
            }

            return "I can provide more details on any cybersecurity topic. Just ask me about passwords, phishing, or safe browsing.";
        }

        private string GetRandomTip(string userInput)
        {
            if (userInput.Contains("password", StringComparison.OrdinalIgnoreCase))
            {
                List<string> tips = _randomTips["password"];
                return tips[_random.Next(tips.Count)];
            }
            else if (userInput.Contains("phishing", StringComparison.OrdinalIgnoreCase))
            {
                List<string> tips = _randomTips["phishing"];
                return tips[_random.Next(tips.Count)];
            }
            else
            {
                List<string> tips = _randomTips["general"];
                return tips[_random.Next(tips.Count)];
            }
        }

        private string ExtractName(string userInput)
        {
            string[] parts = userInput.Split(new[] { "my name is", "call me" }, StringSplitOptions.None);
            if (parts.Length > 1)
            {
                string name = parts[1].Trim().Split(' ')[0];
                return char.ToUpper(name[0]) + name.Substring(1).ToLower();
            }
            return "Friend";
        }

        private string ExtractTopic(string userInput)
        {
            foreach (var keyword in _keywordResponses.Keys)
            {
                if (userInput.Contains(keyword, StringComparison.OrdinalIgnoreCase))
                {
                    return keyword;
                }
            }
            return string.Empty;
        }

        private string GetDefaultResponse(string userInput)
        {
            string[] defaultResponses = {
                "I am not sure about that. Could you ask me about passwords, phishing, or safe browsing?",
                "That is an interesting question. I specialize in cybersecurity topics like password safety and phishing protection.",
                "I want to help you stay safe online. Could you rephrase your question about cybersecurity?",
                "Type 'help' to see all the topics I can assist you with."
            };
            return defaultResponses[_random.Next(defaultResponses.Length)];
        }

        private string DetectSentiment(string userInput)
        {
            if (string.IsNullOrWhiteSpace(userInput))
            {
                return "Neutral";
            }

            string lowerInput = userInput.ToLower();

            foreach (string keyword in _worriedKeywords)
            {
                if (lowerInput.Contains(keyword))
                {
                    return "Worried";
                }
            }

            foreach (string keyword in _frustratedKeywords)
            {
                if (lowerInput.Contains(keyword))
                {
                    return "Frustrated";
                }
            }

            foreach (string keyword in _curiousKeywords)
            {
                if (lowerInput.Contains(keyword))
                {
                    return "Curious";
                }
            }

            foreach (string keyword in _positiveKeywords)
            {
                if (lowerInput.Contains(keyword))
                {
                    return "Positive";
                }
            }

            return "Neutral";
        }

        private string GetEmpathyResponse(string sentiment)
        {
            switch (sentiment)
            {
                case "Worried":
                    string[] worriedResponses = {
                        "I understand your concern. Cybersecurity can feel overwhelming, but let me help you step by step.",
                        "It is completely normal to feel worried about online safety. Let me share some simple tips to protect you.",
                        "Your safety matters. Let me explain this in a simple way that will help ease your mind."
                    };
                    return worriedResponses[_random.Next(worriedResponses.Length)];

                case "Frustrated":
                    string[] frustratedResponses = {
                        "I hear your frustration. Let me break this down more simply for you.",
                        "I apologize if this is confusing. Let me explain it differently to make it clearer.",
                        "I understand this can be frustrating. Let us take it one step at a time."
                    };
                    return frustratedResponses[_random.Next(frustratedResponses.Length)];

                case "Curious":
                    string[] curiousResponses = {
                        "That is a great question! I am glad you are curious about staying safe online.",
                        "Excellent question! Let me give you a detailed explanation.",
                        "I love your curiosity about cybersecurity. Here is what you need to know."
                    };
                    return curiousResponses[_random.Next(curiousResponses.Length)];

                default:
                    return "Let me help you with that.";
            }
        }

        private void UpdateMemory(string userInput)
        {
            _conversationHistory.Add(userInput);

            if (_conversationHistory.Count > 20)
            {
                _conversationHistory.RemoveAt(0);
            }

            DetectInterest(userInput);
        }

        private void DetectInterest(string userInput)
        {
            string[] interestKeywords = {
                "interested in", "like to learn", "want to know",
                "tell me about", "explain", "curious about"
            };

            foreach (string keyword in interestKeywords)
            {
                if (userInput.Contains(keyword, StringComparison.OrdinalIgnoreCase))
                {
                    string interest = ExtractTopicAfterKeyword(userInput, keyword);
                    if (!string.IsNullOrEmpty(interest) && !_userInterests.Contains(interest))
                    {
                        _userInterests.Add(interest);
                    }
                    break;
                }
            }
        }

        private string ExtractTopicAfterKeyword(string text, string keyword)
        {
            int keywordIndex = text.IndexOf(keyword, StringComparison.OrdinalIgnoreCase);
            if (keywordIndex >= 0)
            {
                int startIndex = keywordIndex + keyword.Length;
                if (startIndex < text.Length)
                {
                    string remainder = text.Substring(startIndex).Trim();
                    string[] words = remainder.Split(' ', '.', '!', '?');
                    if (words.Length > 0)
                    {
                        return words[0];
                    }
                }
            }
            return string.Empty;
        }

        private void LogConversation(string entry)
        {
            string timestampedEntry = $"[{DateTime.Now:HH:mm:ss}] {entry}";
            _conversationHistory.Add(timestampedEntry);

            if (_conversationHistory.Count > 100)
            {
                _conversationHistory.RemoveAt(0);
            }
        }

        public string GetPersonalizedGreeting()
        {
            if (string.IsNullOrEmpty(_userName))
            {
                return "Hello! I am CyberGuard, your Cybersecurity Awareness Assistant. What is your name?";
            }
            else if (_userInterests.Count > 0)
            {
                return $"Welcome back {_userName}! I remember you are interested in {_userInterests[0]}. Shall we continue learning about that?";
            }
            else
            {
                return $"Welcome back {_userName}! I am ready to help you stay safe online. What would you like to learn about today?";
            }
        }

        public string GetHelpMessage()
        {
            return "CYBERGUARD HELP MENU\n\n" +
                   "TOPICS I CAN HELP WITH:\n" +
                   "  - Password Safety (ask about passwords)\n" +
                   "  - Phishing Attacks (ask about phishing)\n" +
                   "  - Safe Browsing (ask about safe browsing)\n" +
                   "  - Two-Factor Authentication (ask about 2FA)\n" +
                   "  - Malware Protection (ask about malware)\n" +
                   "  - Privacy Tips (ask about privacy)\n\n" +
                   "CONVERSATION COMMANDS:\n" +
                   "  - 'tell me more' or 'explain more' (get more details)\n" +
                   "  - 'another tip' (get a random security tip)\n" +
                   "  - 'help' or 'menu' (show this menu)\n" +
                   "  - 'quit' or 'exit' (end conversation)\n\n" +
                   "EXAMPLE QUESTIONS:\n" +
                   "  - How do I create a strong password?\n" +
                   "  - What is a phishing attack?\n" +
                   "  - How can I browse safely?\n" +
                   "  - Tell me about two-factor authentication";
        }

        public string GetMemoryStatus()
        {
            if (!string.IsNullOrEmpty(_userName))
            {
                if (_userInterests.Count > 0)
                {
                    return $"User: {_userName} | Interests: {string.Join(", ", _userInterests)}";
                }
                return $"User: {_userName}";
            }
            return "Awaiting user identification";
        }

        public string GetCurrentSentiment(string userInput)
        {
            return DetectSentiment(userInput);
        }

        public void ClearMemory()
        {
            _userName = string.Empty;
            _userInterests.Clear();
            _conversationHistory.Clear();
            _currentTopic = string.Empty;
        }

        public bool IsExitCommand(string input)
        {
            return input.Equals("quit", StringComparison.OrdinalIgnoreCase) ||
                   input.Equals("exit", StringComparison.OrdinalIgnoreCase) ||
                   input.Equals("goodbye", StringComparison.OrdinalIgnoreCase);
        }

        public bool IsHelpCommand(string input)
        {
            return input.Equals("help", StringComparison.OrdinalIgnoreCase) ||
                   input.Equals("menu", StringComparison.OrdinalIgnoreCase);
        }

        public string HandleGoodbye()
        {
            if (!string.IsNullOrEmpty(_userName))
            {
                return $"Goodbye {_userName}! Remember to stay vigilant and keep your data secure. Stay safe online!";
            }
            return "Goodbye! Remember to stay vigilant and keep your data secure. Stay safe online!";
        }
    }
}