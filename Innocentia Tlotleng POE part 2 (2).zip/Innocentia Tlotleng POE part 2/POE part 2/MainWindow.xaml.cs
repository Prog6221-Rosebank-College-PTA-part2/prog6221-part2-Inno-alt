﻿
using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

// Add this reference - you may need to add System.Speech assembly reference
// using System.Speech.Synthesis;

namespace CybersecurityChatbotWPF
{
    public partial class MainWindow : Window
    {
        private Chatbot _chatbot;
        private dynamic _speechSynthesizer;
        private bool _voiceEnabled = true;

        public MainWindow()
        {
            InitializeComponent();
            InitializeChatbot();
        }

        private void InitializeChatbot()
        {
            _chatbot = new Chatbot();

            try
            {
                // Late binding to avoid compile-time errors
                Type speechType = Type.GetType("System.Speech.Synthesis.SpeechSynthesizer, System.Speech");
                if (speechType != null)
                {
                    _speechSynthesizer = Activator.CreateInstance(speechType);
                }
                else
                {
                    _voiceEnabled = false;
                    if (VoiceToggle != null)
                    {
                        VoiceToggle.IsChecked = false;
                        VoiceToggle.Content = "Voice OFF";
                    }
                }
            }
            catch
            {
                _voiceEnabled = false;
                if (VoiceToggle != null)
                {
                    VoiceToggle.IsChecked = false;
                    VoiceToggle.Content = "Voice OFF";
                }
            }

            AddBotMessage(_chatbot.GetPersonalizedGreeting());
            UpdateStatusBar();
        }

        private void AddUserMessage(string message)
        {
            if (ChatPanel == null) return;

            Border messageBorder = new Border();
            messageBorder.Background = (SolidColorBrush)FindResource("UserBubble");
            messageBorder.CornerRadius = new CornerRadius(15);
            messageBorder.Padding = new Thickness(12, 8, 12, 8);
            messageBorder.Margin = new Thickness(5, 3, 50, 3);
            messageBorder.HorizontalAlignment = HorizontalAlignment.Right;

            TextBlock textBlock = new TextBlock();
            textBlock.Text = message;
            textBlock.Foreground = (SolidColorBrush)FindResource("TextLight");
            textBlock.FontSize = 13;
            textBlock.TextWrapping = TextWrapping.Wrap;
            textBlock.MaxWidth = 500;

            messageBorder.Child = textBlock;
            ChatPanel.Children.Add(messageBorder);
            ScrollToBottom();
        }

        private void AddBotMessage(string message)
        {
            if (ChatPanel == null) return;

            Border messageBorder = new Border();
            messageBorder.Background = (SolidColorBrush)FindResource("BotBubble");
            messageBorder.CornerRadius = new CornerRadius(15);
            messageBorder.Padding = new Thickness(12, 8, 12, 8);
            messageBorder.Margin = new Thickness(50, 3, 5, 3);
            messageBorder.HorizontalAlignment = HorizontalAlignment.Left;

            TextBlock textBlock = new TextBlock();
            textBlock.Text = message;
            textBlock.Foreground = (SolidColorBrush)FindResource("TextLight");
            textBlock.FontSize = 13;
            textBlock.TextWrapping = TextWrapping.Wrap;
            textBlock.MaxWidth = 500;

            messageBorder.Child = textBlock;
            ChatPanel.Children.Add(messageBorder);
            ScrollToBottom();

            if (_voiceEnabled && _speechSynthesizer != null)
            {
                try
                {
                    dynamic synth = _speechSynthesizer;
                    synth.SpeakAsync(message);
                }
                catch { }
            }
        }

        private void AddInfoMessage(string message)
        {
            if (ChatPanel == null) return;

            Border infoBorder = new Border();
            infoBorder.Background = new SolidColorBrush(Color.FromRgb(51, 52, 131));
            infoBorder.CornerRadius = new CornerRadius(8);
            infoBorder.Padding = new Thickness(10, 5, 10, 5);
            infoBorder.Margin = new Thickness(50, 3, 50, 3);
            infoBorder.HorizontalAlignment = HorizontalAlignment.Center;

            TextBlock textBlock = new TextBlock();
            textBlock.Text = message;
            textBlock.Foreground = (SolidColorBrush)FindResource("TextMuted");
            textBlock.FontSize = 11;
            textBlock.FontStyle = FontStyles.Italic;

            infoBorder.Child = textBlock;
            ChatPanel.Children.Add(infoBorder);
            ScrollToBottom();
        }

        private void ScrollToBottom()
        {
            if (ChatScrollViewer != null)
            {
                ChatScrollViewer.ScrollToBottom();
            }
        }

        private async void SendButton_Click(object sender, RoutedEventArgs e)
        {
            await ProcessUserInput();
        }

        private async void InputTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                e.Handled = true;
                await ProcessUserInput();
            }
        }

        private async Task ProcessUserInput()
        {
            if (InputTextBox == null) return;

            string userInput = InputTextBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(userInput))
            {
                AddInfoMessage("Please enter a message.");
                return;
            }

            AddUserMessage(userInput);
            InputTextBox.Clear();

            if (_chatbot.IsExitCommand(userInput))
            {
                AddBotMessage(_chatbot.HandleGoodbye());
                await Task.Delay(1500);
                Application.Current.Shutdown();
                return;
            }

            if (_chatbot.IsHelpCommand(userInput))
            {
                AddBotMessage(_chatbot.GetHelpMessage());
                UpdateStatusBar();
                return;
            }

            string sentiment = _chatbot.GetCurrentSentiment(userInput);
            if (SentimentLabel != null)
            {
                SentimentLabel.Text = sentiment;
            }

            string response = await _chatbot.ProcessInput(userInput);
            AddBotMessage(response);

            UpdateStatusBar();
        }

        private void UpdateStatusBar()
        {
            if (MemoryLabel != null)
            {
                string memoryStatus = _chatbot.GetMemoryStatus();
                MemoryLabel.Text = memoryStatus;
            }
        }

        private void VoiceToggle_Checked(object sender, RoutedEventArgs e)
        {
            _voiceEnabled = true;
            if (VoiceToggle != null)
            {
                VoiceToggle.Content = "Voice ON";
            }
            AddInfoMessage("Voice output enabled.");
        }

        private void VoiceToggle_Unchecked(object sender, RoutedEventArgs e)
        {
            _voiceEnabled = false;
            if (VoiceToggle != null)
            {
                VoiceToggle.Content = "Voice OFF";
            }
            if (_speechSynthesizer != null)
            {
                try
                {
                    dynamic synth = _speechSynthesizer;
                    synth.SpeakAsyncCancelAll();
                }
                catch { }
            }
            AddInfoMessage("Voice output disabled.");
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            if (ChatPanel != null)
            {
                ChatPanel.Children.Clear();
            }
            _chatbot.ClearMemory();
            AddBotMessage(_chatbot.GetPersonalizedGreeting());
            if (SentimentLabel != null)
            {
                SentimentLabel.Text = "Neutral";
            }
            if (MemoryLabel != null)
            {
                MemoryLabel.Text = "Ready";
            }
            UpdateStatusBar();
        }
    }
}